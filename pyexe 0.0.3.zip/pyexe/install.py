import platform
import os
import shutil

cwd=os.getcwd()
system=platform.system().lower()


print("installing in "+system)
if system == "linux":
    path="/bin/"
    with open(path+"pyexe","w") as code:
            code.write(f"python3 {cwd} $@")
            code.close()

    os.system("chmod +x "+f"{path}pyexe")
    print("successfully installed")

elif system == "windows":
    path="C:/windows/"
    with open(path+"pyexe.bat","w") as code:
            code.write(f"python {cwd} %*")
            shutil.copy2("./sfk.exe",path)
            code.close()

    print("successfully installed")

