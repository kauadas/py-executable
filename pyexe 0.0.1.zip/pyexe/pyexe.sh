python3 ~/pyexe $@
